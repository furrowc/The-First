package edu.thomas.cs216.data;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.HashMap;

import edu.thomas.cs216.menu.MenuItem;

public class DataManager
{
	
	String filePath = "src/edu/thomas/cs216/data/menu.txt";
	
	HashMap<String, MenuItem> orderItems = new HashMap<String, MenuItem>();
	
	public  DataManager() {
		String id, name, type, description;
		int price;
		
		try (BufferedReader reader = new BufferedReader(new FileReader(filePath)))
		{
			String line = null;
			int count = 0;
			
			while ((line = reader.readLine()) != null){
				String[] words = line.split("\\s");
				id = words[0];
				name = words[1];
				type = words[2];
				description = words[3];
				price = Integer.parseInt(words[4]);
				MenuItem item = new MenuItem(id, name);
				item.setDescription(description);
				item.setPrice(price);
				item.setType(type);
				orderItems.put(id, item);
				count++;
			
			}

	} catch (FileNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (IOException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	}
		public HashMap<String, MenuItem> getMap() {
			
			return orderItems;
		}
	
	


}
