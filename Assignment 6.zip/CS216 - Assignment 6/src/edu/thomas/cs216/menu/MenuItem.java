package edu.thomas.cs216.menu;

public class MenuItem
{

	private String id;
	private String name;
	private String type;
	private String description;
	private double price;


	public MenuItem(String id, String name)
	{
		this.id = id;
		this.name = name;
	}


	public String getId()
	{
		return id;
	}


	public String getName()
	{
		return name;
	}


	public String getDescription()
	{
		return description;
	}


	public String getType()
	{
		return type;
	}


	public double getPrice()
	{
		return price;
	}


	public void setDescription(String description)
	{
		this.description = description;
	}


	public void setType(String type)
	{
		this.type = type;
	}


	public void setPrice(double price)
	{
		this.price = price;
	}
}
