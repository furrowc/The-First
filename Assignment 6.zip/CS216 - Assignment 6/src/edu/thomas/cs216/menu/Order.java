package edu.thomas.cs216.menu;

import java.util.HashMap;

public class Order
{
	HashMap<String, MenuItem> orderItems;
	private final double SALES_TAX = .08;
	
	public void Order() {
		orderItems = new HashMap<String, MenuItem>();
	}
	
	public void add(MenuItem item) {
		String id = item.getId();
		if (!orderItems.containsKey(id)) {
			orderItems.put(id, item);
		}
		else {
			throw new IllegalArgumentException( "You already ordered the " + item.getName());
		}
	}
	public void remove(String itemId) {
		
		MenuItem temp = orderItems.remove(itemId);
		if (temp == null) {
			throw new IllegalArgumentException("That item was not part of your order");
		}
		
	}
	
	public double getTotal() {
		double total = 0;
		for (String id : orderItems.keySet())  {
			
			total = total + orderItems.get(id).getPrice();
		}
		total = total * (1 + SALES_TAX);
		
		return total;
	}
	public MenuItem[] getOrderItems() {
		MenuItem[] menuItems = new MenuItem[orderItems.size()];
		
		int i = 0;
		
		for (MenuItem e : orderItems.values())  {
			menuItems[i] = e;
			i++;
		}
		return menuItems;
	}

}
