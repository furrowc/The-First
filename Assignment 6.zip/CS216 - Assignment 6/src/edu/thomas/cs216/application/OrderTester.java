package edu.thomas.cs216.application;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Scanner;
import java.util.stream.Stream;
import java.io.IOException;
import java.util.HashMap;
import java.util.Random;

import edu.thomas.cs216.data.DataManager;
import edu.thomas.cs216.menu.MenuItem;
import edu.thomas.cs216.menu.Order;

public class OrderTester
{

	public static void main(String[] args)
	{
		// Constant & variable declarations
		final String FILE_PATH = "src/edu/thomas/cs216/data/menu.txt";
		DataManager db = new DataManager();
		HashMap<String, MenuItem> theMenu = db.getMap();
		Order myOrder = null;

		try(BufferedReader reader = new BufferedReader(new FileReader(FILE_PATH)))
		{
			String id = null;
			Scanner in = new Scanner(System.in);
			System.out.println("Welcome to King's Crub Grove, bitch. What would you like to order? (Please enter the food ID, or DONE to stop): ");
			while(!id.equals("DONE")) {
				id = in.nextLine();
				if (theMenu.containsKey(id)) {
					MenuItem item = theMenu.get(id);
					myOrder.add(item);
					System.out.println("You order the " + item.getName() + ", " + item.getDescription() + " please order another item or say 'DONE' to complete your order: ");
				}	
				else {
					System.out.println("Sorry but we do not serve that here, please enter another item or say 'DONE' to complte your order: ");
				}
			}

		}
		
	
		catch (FileNotFoundException fe)
		{
			System.out.println(fe.getMessage());
		}
		catch (IOException e)
		{
			System.out.println(e.getMessage());
		}
		
		Random rand = new Random();
		MenuItem[] items = myOrder.getOrderItems();
		int num = rand.nextInt(items.length);
		
		myOrder.remove((items[num].getId()));
		
		
		System.out.println("-----------------------------------------------------\r\n" + 
				"\r\n" + 
				"We have removed the " + items[num].getName() + " from your order because, frankly, its disgusting.\r\n" + 
				"\r\n" + 
				"Here is your order:\r\n" + 
				"\r\n" + 
				"ID 		Price 	Item\r\n" + 
				"-----------------------------------------------------");
		for (int x = 0; x < items.length; x++) {
			System.out.println(items[x].getId() + "     $" + items[x].getPrice() + "     " + items[x].getName());
		}
		System.out.print("Your total comes to $" + myOrder.getTotal() + ", have a greatn day and come on back ya hear!");
		
		
	}

}
